﻿namespace Talabat.Core.Entities.Order_Aggregate
{
    public class ProductItemOrdered
    {
        
        
        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public string ProductUrl { get; set; }


    }
}